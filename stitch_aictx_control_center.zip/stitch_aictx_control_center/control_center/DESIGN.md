---
name: Control Center
colors:
  surface: '#13121b'
  surface-dim: '#13121b'
  surface-bright: '#393842'
  surface-container-lowest: '#0e0d16'
  surface-container-low: '#1b1b24'
  surface-container: '#1f1f28'
  surface-container-high: '#2a2933'
  surface-container-highest: '#35343e'
  on-surface: '#e4e1ee'
  on-surface-variant: '#c7c4d8'
  inverse-surface: '#e4e1ee'
  inverse-on-surface: '#302f39'
  outline: '#918fa1'
  outline-variant: '#464555'
  surface-tint: '#c3c0ff'
  primary: '#c3c0ff'
  on-primary: '#1d00a5'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#4d44e3'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb695'
  on-tertiary: '#571f00'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#13121b'
  on-background: '#e4e1ee'
  surface-variant: '#35343e'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-xs:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 0.25rem
  sm: 0.5rem
  md: 1rem
  lg: 1.5rem
  xl: 2rem
  gutter: 1rem
  margin: 1.5rem
---

## Brand & Style

This design system is engineered for a "Dark Ops" aesthetic, prioritizing high-density information display and tactical precision. It targets a developer-centric audience that values performance, clarity, and a premium feel reminiscent of industry-leading engineering tools. 

The visual language balances **Minimalism** with **Tactile Brutalism**. It utilizes deep obsidian surfaces, razor-sharp outlines, and vibrant functional accents to guide the eye toward critical actions and system statuses. The emotional response is intended to be one of total control, reliability, and sophisticated utility. Every element is stripped of decorative excess, ensuring that the user’s focus remains entirely on the data and the orchestration of AI workflows.

## Colors

The color palette is anchored in a deep-space neutral scale to minimize eye strain during extended technical sessions. The background uses a pure Neutral 950 to provide maximum contrast for foreground elements.

- **Primary Action:** Indigo 600 is used for high-intent interactions, primary buttons, and active focus states.
- **Success/Status:** Emerald 500 signifies healthy system nodes, successful deployments, and "Up" states.
- **Destructive:** Crimson/Rose 600 is reserved for alerts, errors, and terminal actions.
- **Surfaces:** Neutral 900 serves as the container background, creating a subtle "step up" from the base layer, while Neutral 800 provides the structural definition for all borders and separators.

## Typography

This design system utilizes a dual-font approach to distinguish between navigation and technical data.

**Inter** is the workhorse for the UI, providing exceptional legibility at small sizes. Headings feature tighter letter spacing and heavier weights to evoke a premium, structured feel.

**JetBrains Mono** is utilized for all "system-level" information, including logs, code snippets, metadata, and labels. This typeface reinforces the developer-focused nature of the product, signaling that the information presented is precise and technical. All labels and status indicators should be rendered in uppercase monospace to mimic command-line interfaces.

## Layout & Spacing

The layout philosophy follows a **Fixed-Fluid Hybrid** model. Navigation sidebars and property panels occupy fixed widths to maintain structural consistency, while the central workspace is fluid to maximize the visibility of data visualizations and code editors.

A strict 4px base unit (the "Step") governs all spatial relationships. 
- **Internal Padding:** Use `sm` (8px) for tight components and `md` (16px) for standard card padding.
- **Grid:** A 12-column grid is used for dashboard layouts, with a 16px gutter. 
- **Density:** Information density is high. Use consistent vertical rhythm to ensure complex data tables and log streams remain scannable without excessive scrolling.

## Elevation & Depth

In this design system, depth is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than traditional shadows.

1.  **Level 0 (Base):** Neutral 950 (#0a0a0a). The canvas upon which the system sits.
2.  **Level 1 (Surfaces):** Neutral 900 (#171717). Used for cards, panels, and navigation menus. Surfaces are defined by a 1px solid border of Neutral 800 (#262626).
3.  **Level 2 (Popovers/Modals):** Neutral 900 (#171717). These elements use a slightly brighter border (Neutral 700) and a very subtle, 25% opacity black shadow to create a lift from the Level 1 surface.

Interactive states use "Inner Glows" or subtle border-color shifts to indicate focus, rather than increasing the elevation height.

## Shapes

The shape language is **Soft (0.25rem / 4px)**. This choice aligns with the Shadcn/ui inspiration, providing just enough corner rounding to feel modern and accessible while maintaining the rigid, architectural feel of a professional developer tool.

- **Buttons & Inputs:** Use the base 4px radius.
- **Large Cards:** May utilize an 8px (rounded-lg) radius to create a softer containment for complex nested data.
- **Status Pills:** Utilize a full pill-shape (999px) for status indicators to distinguish them clearly from interactive buttons.

## Components

### Buttons
- **Primary:** Solid Indigo 600 with white text. High contrast.
- **Secondary/Ghost:** Transparent background with a Neutral 800 border. Hover state shifts background to Neutral 800.
- **Destructive:** Crimson 600 solid or outline, reserved for terminal actions.

### Input Fields
- Background is always a shade darker than the parent surface (Neutral 950).
- Borders are Neutral 800, shifting to Indigo 600 on focus.
- Placeholder text is Neutral 600.

### Cards
- Cards feature a Neutral 900 background and a 1px Neutral 800 border.
- Headers within cards should be separated by a subtle 1px divider.

### Data & Logs
- All log streams must use JetBrains Mono.
- Use "Zebra striping" on tables (alternating Neutral 900 and Neutral 950) only when data density is extremely high.
- Success, Warning, and Error states in logs are indicated by a 2px left-border accent in the corresponding functional color.

### Icons
- Use Lucide-style icons with a consistent 1.5px stroke weight.
- Icons should generally be monochromatic (Neutral 400) unless indicating a specific status (e.g., a green checkmark).